/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dividedespesa.business.exceptions;

/**
 *
 * @author Carlos Pereira
 */
public class CarateresEspeciaisException extends Exception {

    /**
     * Creates a new instance of <code>CarateresEspeciaisException</code>
     * without detail message.
     */
    public CarateresEspeciaisException() {
    }

    /**
     * Constructs an instance of <code>CarateresEspeciaisException</code> with
     * the specified detail message.
     *
     * @param msg the detail message.
     */
    public CarateresEspeciaisException(String msg) {
        super(msg);
    }
}
